#include"Draw_model.h"
#include"light.h"
#include"skyBox.h"
#include<Windows.h>

const float pi = 3.14159;
const float viewTransSpeed = 1.0f;       // ������ƶ��ٶ�

float viewPos[] = { 0, 0, 10 };          // �����λ��
float viewCenter[] = { 0, 0, 5 };        // ������۲��
float viewRotateAngle = 0.0f;            // �ӽ�ƫת�Ƕ�
float cameraForward[] = { 0, 0, -1 };          // ���������

objModel building, bell, lightObj, jiaju, niu;
bool bellRotateAngleAdd = true;       // ��������ת�Ƕ�����

float lightTrans[] = { 0.0f, 0.0f, 0.0f };      // �Ƶ�ƫ��       // ���ڽ������������ƶ�
float lightRotateAngle = 0.0f;                  // �Ƶ���ת�Ƕ�   // ���ڽ�������������ת
float lightScale = 1.0f;      // �Ƶ����ų̶�   // ���ڽ���������������

DirectionLight light(GL_LIGHT0);

bool bCameraRotate = false;   //  ������Ƿ�������ת
float cameraXZRotateAngle = 0;   // �����xzƽ���ڵ���ת�Ƕ� ��������ת
float cameraYRotateAngle = 0;   //  �������ֱƽ���ڵ���ת�Ƕ�   ������ת

int lastMousePosX, lastMousePosY;  //  �ϴ�����λ��  

skyBox sky;
float lightAngle = 0.0f;
float niuPos = 0.0f;
bool nforward = true;
bool lightAc = true;

float pLightPos[][3] = { {3.0f, -0.5f, -10.4f}, { 3.0f, -0.5f, -19.4f } ,
{ 3.0f, -0.5f, -28.6f } , { -10.0f, -0.5f, -28.6f } , { -10.0f, -0.5f, -28.6f } , { -10.0f, -0.5f, -28.6f } };


PointLight *pLight[6];

DWORD last;

bool startPartical = false;
bool night = false;

void init()
{
	glClearColor(0.55, 0.65, 0.8, 1.0);

	glMatrixMode(GL_PROJECTION);
	gluPerspective(60.0f, 1200.0f / 900.0f, 0.1f, 500.0f);       // ����ͶӰ����

	glMatrixMode(GL_MODELVIEW);
	gluLookAt(viewPos[0], viewPos[1], viewPos[2],
		viewCenter[0], viewCenter[1], viewCenter[2],
		0, 1, 0);                       // ����ģ���ӿھ���

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);

	building.loadObjModel("Res/building.obj");
	bell.loadObjModel("Res/bell.obj");
	lightObj.loadObjModel("Res/light.obj");
	jiaju.loadObjModel("Res/jiaju.obj");
	niu.loadObjModel("Res/niu.obj");

	light.SetAmbientColor(0.1, 0.1, 0.1, 1.0);
	light.SetDiffuseColor(0.8, 0.8, 0.8, 1.0);
	light.SetSpecularColor(1.0, 1.0, 1.0, 1.0);
	light.SetPosition(1.0, 1, 1.0);
	light.Enable();

	pLight[0] = new PointLight(GL_LIGHT1);
	pLight[1] = new PointLight(GL_LIGHT1);
	pLight[2] = new PointLight(GL_LIGHT1);
	pLight[3] = new PointLight(GL_LIGHT1);
	pLight[4] = new PointLight(GL_LIGHT1);
	pLight[5] = new PointLight(GL_LIGHT1);

	for (int i = 0; i < 6; ++i)
	{
		pLight[i]->SetAmbientColor(0.1f, 0.1f, 0.1f, 1.0f);
		pLight[i]->SetDiffuseColor(0.4f, 0.4f, 0.01f, 1.0f);
		pLight[i]->SetSpecularColor(0.4f, 0.4f, 0.01f, 1.0f);
		pLight[i]->SetPosition(pLightPos[i][0], pLightPos[i][1], pLightPos[i][2]);
		pLight[i]->SetConstAttenuation(10.0);
		pLight[i]->SetLinearAttenuation(100.0);
		pLight[i]->SetQuadricAttenuation(100.0);
	}

	sky.Init();

	last = GetTickCount64();
}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	static float angle = 0.0f;
	if(lightAc)
		lightAngle += pi / 360.0f;
	if (lightAngle >= 2.0 * pi)
		lightAngle -= 2.0 * pi;

	if (night)
	{
		for (int i = 0; i < 6; ++i)
		{
			for (int i = 0; i < 6; ++i)
			{
				pLight[i]->SetPosition(pLightPos[i][0], pLightPos[i][1], pLightPos[i][2]);
				pLight[i]->Enable();
			}
		}
		light.Disable();
	}
	else
	{
		for (int i = 0; i < 6; ++i)
		{
			pLight[i]->Disable();
		}
		light.Enable();
	}
	
	sky.Draw(viewPos[0], viewPos[1], viewPos[2]);


	light.SetPosition(cos(lightAngle), sin(lightAngle), 0.0f);

	glPushMatrix();
	building.objDraw();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(12.0f, -7.5f, -31.0f + niuPos);
	if(nforward)
		glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
	niu.objDraw();
	glPopMatrix();

	if (nforward)
	{
		niuPos -= 0.01f;
		if (niuPos <= -15.0f)
			nforward = false;
	}
	else
	{
		niuPos += 0.01f;
		if (niuPos >= 0.0f)
			nforward = true;
	}

	glPushMatrix();
	glTranslatef(10.0f, -6.2f, -43.0f);
	glScalef(0.15f, 0.15f, 0.15f);
	jiaju.objDraw();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(15.62f, -2.15f, -27.1f);
	glRotatef(angle, 1.0f, 0.0f, 0.0f);
	glTranslatef(-15.62f, 2.15f, 27.1f);
	bell.objDraw();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(lightTrans[0], lightTrans[1], lightTrans[2]);
	glScalef(lightScale, lightScale, lightScale);
	glPushMatrix();	
	glTranslatef(10.03, 0, -16.75);
	glRotatef(lightRotateAngle, 0.0f, 1.0f, 0.0f);
	glTranslatef(-10.03, 0, 16.75);
	lightObj.objDraw();
	glPopMatrix();
	glPopMatrix();

	//   ������ת����
	if(bellRotateAngleAdd)
		angle += 2.0f;
	else if(!bellRotateAngleAdd)
		angle -= 2.0f;

	if (bellRotateAngleAdd && angle >= 60.0f)
		bellRotateAngleAdd = false;
	if (!bellRotateAngleAdd && angle <= -60.0f)
		bellRotateAngleAdd = true;

	DWORD current = GetTickCount64();
	float frameCost = float(current - last) / 1000.0f;
	last = current;

	glutSwapBuffers();
	glutPostRedisplay();
}

void keyFunc(GLubyte key, int x, int y)
{
	/*
	ws  ��������ͷǰ������

	ik  ���Ƶ������ƶ�
	jl  ���Ƶ������ƶ�
	uo  ���Ƶ�������ת
	nm  ���Ƶ�����

	y �����ҹ�仯
	*/
	switch (key)
	{
	case 'w':
		for (int i = 0; i < 3; ++i)
		{
			viewPos[i] += cameraForward[i];
			viewCenter[i] += cameraForward[i];
		}
		break;

	case 's':
		for (int i = 0; i < 3; ++i)
		{
			viewPos[i] -= cameraForward[i];
			viewCenter[i] -= cameraForward[i];
		}
		break;

	case 'i':
		lightTrans[1] += 1.0f;
		break;
	case 'k':
		lightTrans[1] -= 1.0f;
		break;
	case 'j':
		lightTrans[0] -= 1.0f;
		break;
	case 'l':
		lightTrans[0] += 1.0f;
		break;
	case 'u':
		lightRotateAngle += 3.0f;
		break;
	case 'o':
		lightRotateAngle -= 3.0f;
		break;
	case 'n':
		lightScale -= 0.5f;
		if (lightScale <= 0.0f)
			lightScale = 0.5f;
		break;
	case 'm':
		lightScale += 0.5f;
		break;

	case 'y':
		lightAc = !lightAc;
		break;
		
	case 'v':
		startPartical = !startPartical;
		break;

	case 'b':
		night = !night;
		break;
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(viewPos[0], viewPos[1], viewPos[2],
		viewCenter[0], viewCenter[1], viewCenter[2],
		0, 1, 0);

	glutPostRedisplay();
}

void MouseFunc(int button, int state, int x, int y)           // ������¼�
{
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		bCameraRotate = true;
	}
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_UP)
	{
		bCameraRotate = false;
	}
}

/*
	����Ҽ����£��϶����ʵ��������ڶ�
*/
void MotionFunc(int x, int y)        // ����ƶ��¼�
{
	y = 900 - y;

	if (bCameraRotate)
	{
		if (x > lastMousePosX)
		{
			cameraXZRotateAngle += 0.02f;
			lastMousePosX = x;
		}
		else if (x < lastMousePosX)
		{
			cameraXZRotateAngle -= 0.02f;
			lastMousePosX = x;
		}

		if (y > lastMousePosY)
		{
			cameraYRotateAngle += 0.02f;
			lastMousePosY = y;
		}
		else if (y < lastMousePosY)
		{
			cameraYRotateAngle -= 0.02f;
			lastMousePosY = y;
		}
	}

	cameraForward[0] = sin(cameraXZRotateAngle);
	cameraForward[2] = -cos(cameraXZRotateAngle);
	cameraForward[1] = sin(cameraYRotateAngle);

	float length = sqrt(cameraForward[0] * cameraForward[0] +
		cameraForward[1] * cameraForward[1] +
		cameraForward[2] * cameraForward[2]);


	for (int i = 0; i < 3; ++i)
	{
		cameraForward[i] /= length;
		viewCenter[i] = viewPos[i] + cameraForward[i];
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(viewPos[0], viewPos[1], viewPos[2],
		viewCenter[0], viewCenter[1], viewCenter[2],
		0, 1, 0);
	glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
	glutInitWindowPosition(200, 100);
	glutInitWindowSize(1200, 800);
	glutCreateWindow("opengl");

	init();

	glutDisplayFunc(display);
	glutKeyboardFunc(keyFunc);
	glutMouseFunc(MouseFunc);
	glutMotionFunc(MotionFunc);

	glutMainLoop();

	return 0;
}