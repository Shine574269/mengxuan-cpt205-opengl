#pragma once
#include"utils.h"

class skyBox
{
public:
	void Init();
	void Draw(float x, float y, float z);
private:
	GLuint mFrontTexture, mBackTexture, mLeftTexture, mRightTexture, mTopTexture, mBottomTexture;
};