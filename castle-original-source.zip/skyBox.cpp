#include "skyBox.h"

void skyBox::Init()
{
	mFrontTexture = CreateTexture("Res/skybox/front.jpg");
	mBackTexture = CreateTexture("Res/skybox/back.jpg");
	mLeftTexture = CreateTexture("Res/skybox/right.jpg");
	mRightTexture = CreateTexture("Res/skybox/left.jpg");
	mTopTexture = CreateTexture("Res/skybox/top.jpg");
	mBottomTexture = CreateTexture("Res/skybox/bottom.jpg");
}

void skyBox::Draw(float x,float y,float z)
{
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);

	glColor4ub(255, 255, 255, 255);
	glBindTexture(GL_TEXTURE_2D, mFrontTexture);         //ǰ
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 0.0f);	glVertex3f(x-0.5f, y-0.5f,z -0.5f);
	glTexCoord2f(1.0f, 0.0f);	glVertex3f(x+0.5f, y-0.5f,z -0.5f);
	glTexCoord2f(1.0f, 1.0f);	glVertex3f(x+0.5f, y+0.5f,z -0.5f);
	glTexCoord2f(0.0f, 1.0f);	glVertex3f(x-0.5f,y +0.5f,z -0.5f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, mBackTexture);         //��
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 0.0f);	glVertex3f(x+0.5f, y-0.5f, z+0.5f);
	glTexCoord2f(1.0f, 0.0f);	glVertex3f(x-0.5f, y-0.5f, z+0.5f);
	glTexCoord2f(1.0f, 1.0f);	glVertex3f(x-0.5f, y+0.5f, z+0.5f);
	glTexCoord2f(0.0f, 1.0f);	glVertex3f(x+0.5f, y+0.5f, z+0.5f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, mLeftTexture);         //��
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 0.0f);	glVertex3f(x-0.5f, y-0.5f,z+ 0.5f);
	glTexCoord2f(1.0f, 0.0f);	glVertex3f(x-0.5f, y-0.5f, z-0.5f);
	glTexCoord2f(1.0f, 1.0f);	glVertex3f(x-0.5f, y+0.5f,z -0.5f);
	glTexCoord2f(0.0f, 1.0f);	glVertex3f(x-0.5f,y+ 0.5f,z+ 0.5f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, mRightTexture);         //��
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 0.0f);	glVertex3f(x+0.5f, y-0.5f,z -0.5f);
	glTexCoord2f(1.0f, 0.0f);	glVertex3f(x+0.5f,y -0.5f, z+0.5f);
	glTexCoord2f(1.0f, 1.0f);	glVertex3f(x+0.5f, y+0.5f, z+0.5f);
	glTexCoord2f(0.0f, 1.0f);	glVertex3f(x+0.5f, y+0.5f,z -0.5f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, mTopTexture);         //��
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 0.0f);	glVertex3f(x-0.5f,y+ 0.5f,z -0.5f);
	glTexCoord2f(1.0f, 0.0f);	glVertex3f(x+0.5f,y+0.5f,z -0.5f);	
	glTexCoord2f(1.0f, 1.0f);	glVertex3f(x+0.5f, y+0.5f,z+ 0.5f);
	glTexCoord2f(0.0f, 1.0f);	glVertex3f(x-0.5f,y+ 0.5f,z+ 0.5f);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, mBottomTexture);         //��
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 0.0f);	glVertex3f(x-0.5f, y-0.5f,z+ 0.5f);
	glTexCoord2f(1.0f, 0.0f);	glVertex3f(x+0.5f, y-0.5f, z+0.5f);
	glTexCoord2f(1.0f, 1.0f);	glVertex3f(x+0.5f, y-0.5f, z-0.5f);
	glTexCoord2f(0.0f, 1.0f);	glVertex3f(x-0.5f, y-0.5f,z -0.5f);
	glEnd();


	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
}